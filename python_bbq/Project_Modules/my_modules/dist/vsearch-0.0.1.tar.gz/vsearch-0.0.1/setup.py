from setuptools import setup
setup(
    name='vsearch',
    version='0.0.1',
    description='check if a string is in a text',
    author='someone',
    url='www.blabla.com',
    py_modules=['vsearch']
)