from setuptools import setup
setup(
    name='is_palindrome',
    version='0.0.1',
    description='check if a string is palindrome',
    author='someone',
    url='www.blabla.com',
    py_modules=['palindrome']
)